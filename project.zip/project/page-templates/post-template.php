<?php
/**
 * Template Name: Custom Post Template
 * Template Post Type: post
 */
get_header(); 
?>

<?php
get_footer();
?>